import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
    resume: any = null;

  constructor(private http: HttpClient) {}
     
 ngOnInit(): void {
   this.http.get('https://gist.githubusercontent.com/Naveen9911/a7390c2347db75f76fef64e61da43eab/raw/eac01a81ededecc0ab89dcbef0e79b8ac55111c3/resume.json')
   .subscribe(res => {
    this.resume = res;
    console.log(res);
   });
 }
}  

